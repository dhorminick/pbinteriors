<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <title>Interior Architect an Interior Category Bootstrap Responsive Website Template | About :: W3layouts</title>
     <!-- web fonts -->
    <link href="//fonts.googleapis.com/css?family=Poppins:300,400,500,600,700,800,900&display=swap" rel="stylesheet">
    <link href="//fonts.googleapis.com/css?family=Hind&display=swap" rel="stylesheet">
    <!-- //web fonts -->
    <!-- Template CSS -->
    <link rel="stylesheet" href="/assets/css/main.css">
    <link rel="stylesheet" href="/assets/css/custom.css">
  </head>
  <body>

<!-- header -->
<?php include '../inc/header.inc.php'; ?>
<!-- //header -->

<section class="w3l-about-breadcrum" style="display: none;">
  <div class="breadcrum-bg">
    <div class="container py-5">
      <p><a href="/">Home</a> &nbsp; / &nbsp; About</p>
      <h2 class="my-3">About Us</h2>
      <p>
        A Customer and investor oriented interior company, selling optimum beauty and comfort. 
      </p>
    </div>
  </div>
</section>

<!--  recent projects section -->
<section class="w3l-index6" id="about">
  <div class="features-with-17_sur">
    <div class="container py-lg-5">
      <div class="products-4" id="gallery">
        <!-- Products4 block -->
        <div id="products4-block" class="text-center">
            <div class="container">
                <!-- labels -->
                <input id="tab1" type="radio" name="tabs" checked>
                <label class="tabtle" for="tab1">All Projects</label>

                <input id="tab2" type="radio" name="tabs">
                <label class="tabtle" for="tab2">Residential Interiors</label>

                <input id="tab3" type="radio" name="tabs">
                <label class="tabtle" for="tab3">Other Interiors</label>
                <!-- labels -->
                <section id="content1" class="tab-content text-left">
                  <div class="d-grid grid-col-3">
                      <div class="product">
                          <a href="/assets/images/g1.jpg" data-lightbox="example-set"
                              data-title="Lorem ipsum dolor sit amet consectetur adipisicing elit. Numquam architecto, ex veritatis">
                              <figure>
                                  <img src="/assets/images/g1.jpg" class="img-responsive" alt="" />
                              </figure>
                              <div class="work-description">
                                Residential Apartment<br>
                                Ilaro, Abeokuta.
                              </div>
                          </a>
                      </div>
                      <div class="product">
                          <a href="/assets/images/g2.jpg" data-lightbox="example-set"
                              data-title="Lorem ipsum dolor sit amet consectetur adipisicing elit. Numquam architecto, ex veritatis">
                              <figure>
                                  <img src="/assets/images/g2.jpg" class="img-responsive" alt="" />
                              </figure>
                              <div class="work-description">
                                Bathroom<br>
                                Pansheke, Abeokuta.
                              </div>
                          </a>
                      </div>
                      <div class="product">
                          <a href="/assets/images/g3.jpg" data-lightbox="example-set"
                              data-title="Lorem ipsum dolor sit amet consectetur adipisicing elit. Numquam architecto, ex veritatis">
                              <figure>
                                  <img src="/assets/images/g3.jpg" class="img-responsive" alt="" />
                              </figure>
                              <div class="work-description">
                                Residential Apartment<br>
                                Harmony, Abeokuta.
                              </div>
                          </a>
                      </div>
                      <div class="product">
                          <a href="/assets/images/g4.jpg" data-lightbox="example-set"
                              data-title="Lorem ipsum dolor sit amet consectetur adipisicing elit. Numquam architecto, ex veritatis">
                              <figure>
                                  <img src="/assets/images/g4.jpg" class="img-responsive" alt="" />
                              </figure>
                              <div class="work-description">
                                Living Room<br>
                                Harmony, Abeokuta.
                              </div>
                          </a>
                      </div>
                      <div class="product">
                          <a href="/assets/images/g5.jpg" data-lightbox="example-set"
                              data-title="Lorem ipsum dolor sit amet consectetur adipisicing elit. Numquam architecto, ex veritatis">
                              <figure>
                                  <img src="/assets/images/g5.jpg" class="img-responsive" alt="" />
                              </figure>
                              <div class="work-description">
                                Sitting Room<br>
                                Harmony, Abeokuta.
                              </div>
                          </a>
                      </div>
                      <div class="product">
                          <a href="/assets/images/g6.jpg" data-lightbox="example-set"
                              data-title="Lorem ipsum dolor sit amet consectetur adipisicing elit. Numquam architecto, ex veritatis">
                              <figure>
                                  <img src="/assets/images/g6.jpg" class="img-responsive" alt="" />
                              </figure>
                              <div class="work-description">
                                Bed Room<br>
                                Accord Estate, Abeokuta.
                              </div>
                            </a>
                      </div>
                  </div>
                </section>
                <section id="content2" class="tab-content text-left">
                  <div class="d-grid grid-col-3">
                      <div class="product">
                          <a href="/assets/images/g1.jpg" data-lightbox="example-set"
                              data-title="Lorem ipsum dolor sit amet consectetur adipisicing elit. Numquam architecto, ex veritatis">
                              <figure>
                                  <img src="/assets/images/g1.jpg" class="img-responsive" alt="" />
                              </figure>
                              <div class="work-description">
                                Residential Apartment<br>
                                Ilaro, Abeokuta.
                              </div>
                          </a>
                      </div>
                      <div class="product">
                          <a href="/assets/images/g2.jpg" data-lightbox="example-set"
                              data-title="Lorem ipsum dolor sit amet consectetur adipisicing elit. Numquam architecto, ex veritatis">
                              <figure>
                                  <img src="/assets/images/g2.jpg" class="img-responsive" alt="" />
                              </figure>
                              <div class="work-description">
                                Bathroom<br>
                                Pansheke, Abeokuta.
                              </div>
                          </a>
                      </div>
                      <div class="product">
                          <a href="/assets/images/g3.jpg" data-lightbox="example-set"
                              data-title="Lorem ipsum dolor sit amet consectetur adipisicing elit. Numquam architecto, ex veritatis">
                              <figure>
                                  <img src="/assets/images/g3.jpg" class="img-responsive" alt="" />
                              </figure>
                              <div class="work-description">
                                Residential Apartment<br>
                                Harmony, Abeokuta.
                              </div>
                          </a>
                      </div>
                      <div class="product">
                          <a href="/assets/images/g4.jpg" data-lightbox="example-set"
                              data-title="Lorem ipsum dolor sit amet consectetur adipisicing elit. Numquam architecto, ex veritatis">
                              <figure>
                                  <img src="/assets/images/g4.jpg" class="img-responsive" alt="" />
                              </figure>
                              <div class="work-description">
                                Living Room<br>
                                Harmony, Abeokuta.
                              </div>
                          </a>
                      </div>
                  </div>
                </section>
                <section id="content3" class="tab-content text-left">
                  <div class="d-grid grid-col-3">
                      <div class="product">
                          <a href="/assets/images/g5.jpg" data-lightbox="example-set"
                              data-title="Lorem ipsum dolor sit amet consectetur adipisicing elit. Numquam architecto, ex veritatis">
                              <figure>
                                  <img src="/assets/images/g5.jpg" class="img-responsive" alt="" />
                              </figure>
                              <div class="work-description">
                                Sitting Room<br>
                                Harmony, Abeokuta.
                              </div>
                          </a>
                      </div>
                      <div class="product">
                          <a href="/assets/images/g6.jpg" data-lightbox="example-set"
                              data-title="Lorem ipsum dolor sit amet consectetur adipisicing elit. Numquam architecto, ex veritatis">
                              <figure>
                                  <img src="/assets/images/g6.jpg" class="img-responsive" alt="" />
                              </figure>
                              <div class="work-description">
                                Bed Room<br>
                                Accord Estate, Abeokuta.
                              </div>
                            </a>
                      </div>
                  </div>
                </section>
            </div>
        </div>
        <!-- Products4 block -->
    </div>
    </div>
  </div>
</section>
<!--  //recent projects section -->

<!-- sell your property block1 -->
<?php include '../inc/sell.inc.php'; ?>
<!-- //sell your property block1 -->

<!-- footer -->
<?php include '../inc/footer.inc.php'; ?>
<!-- //footer -->

<script src="/assets/js/jquery-3.3.1.min.js"></script>

<script>
    $(function () {
      $('.navbar-toggler').click(function () {
        $('body').toggleClass('noscroll');
      })
    });
</script>
<!-- jQuery first, then Popper.js, then Bootstrap JS -->
<script src="https://code.jquery.com/jquery-3.4.1.slim.min.js"
  integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous">
</script>
  
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"
  integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous">
</script>
<!-- Smooth scrolling -->

<script src="/assets/js/owl.carousel.js"></script>

<!-- script for -->
<script>
  $(document).ready(function () {
    $('.owl-one').owlCarousel({
      loop: true,
      margin: 0,
      nav: true,
      responsiveClass: true,
      autoplay: false,
      autoplayTimeout: 5000,
      autoplaySpeed: 1000,
      autoplayHoverPause: false,
      responsive: {
        0: {
          items: 1,
          nav: false
        },
        480: {
          items: 1,
          nav: false
        },
        667: {
          items: 1,
          nav: true
        },
        1000: {
          items: 1,
          nav: true
        }
      }
    })
  })

  $(".product").hover(function(){
    $(this).addClass("active");
  }, function(){
    $(this).removeClass("active");
  });
</script>
<!-- //script -->

</body>

</html>
<!-- // grids block 5 -->

