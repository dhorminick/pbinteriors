<section class="w3l-footer-29-main" id="footer">
  <div class="footer-29">
      <div class="grids-forms-1 pb-5">
        <div class="container">
          <div class="grids-forms">
            <div class="main-midd">
                <h4 class="title-head">Newsletter – Get Updates & Latest News</h4>
                
            </div>
            <div class="main-midd-2">
                <form action="#" method="post" class="rightside-form">
                    <input type="email" name="email" placeholder="Enter your email">
                    <button class="btn" type="submit">Subscribe</button>
                </form>
            </div>
          </div>
        </div>
      </div>
      <div class="container pt-5">
          <div class="d-grid grid-col-4 footer-top-29">
              <div class="footer-list-29 footer-1">
                  <h6 class="footer-title-29">About Us</h6>
                  <ul>
                        <p>
                        A subsidary of PB Creative Enterprise that focuses on interior designs, 
                        apartment rentals and purchases. Set out to bring a new bliss to the interior 
                        industry with state of the art designs and architecture. 
                        </p>
                  </ul>
                  <div class="main-social-footer-29">
                    <h6 class="footer-title-29">Social Links</h6>
                      <a href="#facebook" class="facebook"><span class="fa fa-facebook"></span></a>
                      <a href="#twitter" class="twitter"><span class="fa fa-twitter"></span></a>
                      <a href="#instagram" class="instagram"><span class="fa fa-instagram"></span></a>
                      <a href="#google-plus" class="google-plus"><span class="fa fa-google-plus"></span></a>
                      <a href="#linkedin" class="linkedin"><span class="fa fa-linkedin"></span></a>
                  </div>
              </div>
              <div class="footer-list-29 footer-2">
                    <ul>
                        <h6 class="footer-title-29">Useful Links</h6>
                        <li><a href="services.html">Our Interiors</a></li>
                        <li><a href="services.html">Serviced Apartment</a></li>
                        <li><a href="services.html">Purchase A Home</a></li>
                    </ul>
              </div>
              <div class="footer-list-29 footer-3">
                <ul>
                    <h6 class="footer-title-29">Work Hours</h6>
                    <li><a>Mon - Sat (Open 24 Hours)</a></li>
                </ul><br>
                <ul>
                    <h6 class="footer-title-29">Available Locations</h6>
                    <li><a href="search?location=abeokuta">Abeokuta</a></li>
                    <li><a href="search?location=lagos">Lagos</a></li>
                    <li><a href="/available-locations">View All <i class="fa fa-angle-right"></i></a></li>
                </ul>
              </div>
              <div class="footer-list-29 footer-3" style="display: none;">
                  <div class="properties">
                      <h6 class="footer-title-29">Recent Projects</h6>
                      <a href="#"><img src="assets/images/g2.jpg" class="img-responsive" alt=""><p>We Are Leading International Consultiing Agency</p></a>
                      <a href="#"><img src="assets/images/g8.jpg" class="img-responsive" alt=""><p>Digital Marketing Agency all the foundational tools</p></a>
                      <a href="#"><img src="assets/images/g6.jpg" class="img-responsive" alt=""><p>Doloremque velit sapien labore eius itna</p></a>
                  </div>
              </div>
              <div class="footer-list-29 footer-4">
                  <ul>
                      <h6 class="footer-title-29">Quick Links</h6>
                      <li><a href="/">Home</a></li>
                      <li><a href="about">About Us</a></li>
                      <li><a href="services">Our Services</a></li>
                      <li><a href="">Interiors</a></li>
                      <li><a href=""> Real Estate</a></li>
                      <li><a href="contact">Contact Us</a></li>
                  </ul>
              </div>
          </div>
          <div class="bottom-copies text-center">
              <p class="copy-footer-29">© 2020 Interior Architect. All rights reserved | Designed by <a href="https://w3layouts.com">W3layouts</a></p>
               
          </div>
      </div>
  </div>
   <!-- move top -->
  <button onclick="topFunction()" id="movetop" title="Go to top">
    <span class="fa fa-angle-up"></span>
  </button>
  <script src="assets/js/totop.js"></script>
  <!-- /move top -->
</section>