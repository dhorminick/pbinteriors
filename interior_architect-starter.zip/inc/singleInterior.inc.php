<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <title>Interior Architect an Interior Category Bootstrap Responsive Website Template | Home :: W3layouts</title>
     <!-- web fonts -->
    <link href="//fonts.googleapis.com/css?family=Poppins:300,400,500,600,700,800,900&display=swap" rel="stylesheet">
    <link href="//fonts.googleapis.com/css?family=Hind&display=swap" rel="stylesheet">
    <!-- //web fonts -->
    <!-- Template CSS -->
    <link rel="stylesheet" href="/assets/css/main.css">
    <link rel="stylesheet" href="/assets/css/custom.css">
    <link rel="stylesheet" href="/assets/css/gallery.css">
  </head>
  <body>

<!-- header -->
<?php include 'header.inc.php'; ?>
<!-- //header -->

<!-- breadcrum -->
<section class="w3l-about-breadcrum">
  <div class="breadcrum-bg">
    <div class="container py-5">
      <p><a href="/">Home</a> &nbsp; / &nbsp; About</p>
      <h2 class="my-3">About Us</h2>
      <p>
        A Customer and investor oriented interior company, selling optimum beauty and comfort. 
      </p>
    </div>
  </div>
</section>
<!-- //breadcrum -->

<!--  build a space section -->
<section class="w3l-index6" id="about" style="display: none;">
  <div class="features-with-17_sur py-5">
    <div class="container py-lg-5">
      <div class="features-with-17-top_sur mt-5 pt-3">
        <div class="row">
          <div class="col-lg-12 mt-md-0 mt-4">
                <div class="product">
                    <figure>
                        <img src="/assets/images/g1.jpg" class='interior-image' alt="" />
                    </figure>
                </div>
          </div><br>
          <div class="col-lg-12 mt-md-0 mt-5">
            <div class="features-with-17-right-tp_sur">
              <div class="features-with-17-left1 mb-3">
                <span class="fa fa-ils" aria-hidden="true"></span>
              </div>
              <div class="features-with-17-left2">
                <h6><a href="#url">Conceptual Architecture</a></h6>
                <p>We work with the range of crafts people in the field of furnitures, 
                  electronics, wall and floor plastering, design makers and technocrats to offer our 
                  clients bespoke and made to measure products.  
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>
<!--  //build a space section -->

<!-- Container for the image gallery -->
<section class="w3l-index6" id="about">
    <div class="features-with-17_sur py-5 py-lg-5">
        <div class="container">

        <!-- Full-width images with number text -->
        <div class="mySlides">
            <div class="numbertext">1 / 6</div>
            <img src="/assets/images/g1.jpg" class='interior-image'>
        </div>

        <div class="mySlides">
            <div class="numbertext">2 / 6</div>
            <img src="/assets/images/g2.jpg" class='interior-image'>
        </div>

        <div class="mySlides">
            <div class="numbertext">3 / 6</div>
            <img src="/assets/images/g3.jpg" class='interior-image'>
        </div>

        <div class="mySlides">
            <div class="numbertext">4 / 6</div>
            <img src="/assets/images/g4.jpg" class='interior-image'>
        </div>

        <div class="mySlides">
            <div class="numbertext">5 / 6</div>
            <img src="/assets/images/g5.jpg" class='interior-image'>
        </div>

        <div class="mySlides">
            <div class="numbertext">6 / 6</div>
            <img src="/assets/images/g6.jpg" class='interior-image'>
        </div>

        <!-- Next and previous buttons -->
        <a class="prev" onclick="plusSlides(-1)">&#10094;</a>
        <a class="next" onclick="plusSlides(1)">&#10095;</a>

        <!-- Image text -->
        <div class="caption-container">
            <p id="caption"></p>
        </div>

        <!-- Thumbnail images -->
        <div class="img-row">
            <div class="img-column">
            <img class="demo cursor" src="/assets/images/g1.jpg" style="width:100%" onclick="currentSlide(1)" alt="The Woods">
            </div>
            <div class="img-column">
            <img class="demo cursor" src="/assets/images/g2.jpg" style="width:100%" onclick="currentSlide(2)" alt="Cinque Terre">
            </div>
            <div class="img-column">
            <img class="demo cursor" src="/assets/images/g3.jpg" style="width:100%" onclick="currentSlide(3)" alt="Mountains and fjords">
            </div>
            <div class="img-column">
            <img class="demo cursor" src="/assets/images/g4.jpg" style="width:100%" onclick="currentSlide(4)" alt="Northern Lights">
            </div>
            <div class="img-column">
            <img class="demo cursor" src="/assets/images/g5.jpg" style="width:100%" onclick="currentSlide(5)" alt="Nature and sunrise">
            </div>
            <div class="img-column">
            <img class="demo cursor" src="/assets/images/g6.jpg" style="width:100%" onclick="currentSlide(6)" alt="Snowy Mountains">
            </div>
        </div>
        </div>
    </div>
    <div class="features-with-17_sur">
      <div class="container">
        <h3 class="head">Specifications</h3>
      </div>
    </div>
</section>

<!--  build a space section -->
<section class="w3l-index6" id="about" style="display: none;">
  <div class="features-with-17_sur py-5">
    <div class="container py-lg-5">
      <div class="heading text-center mx-auto mb-5">
        <h3 class="head">A Space That Feels Like You.</h3>
        <p class="my-3 head"> 
          Are you searching for an experienced interior designer to beautify your homes and offices, or a fully furnished apartment
          for one-time rentals or full purchase, at <strong>pbinteriors</strong>, we offer:
        </p>
      </div>
      <div class="features-with-17-top_sur mt-5 pt-3">
        <div class="row">
          <div class="col-lg-4 col-md-6 mt-md-0 mt-4">
            <div class="features-with-17-right-tp_sur">
              <div class="features-with-17-left1 mb-3">
                <span class="fa fa-paint-brush" aria-hidden="true"></span>
              </div>
              <div class="features-with-17-left2">
                <h6><a href="#url">Quality Re-assurance</a></h6>
                <p> We select well-designed products that are made to the highest standards of quality 
                  and sustainability, with materials destined to satisfy our customers very need. 
                </p>
              </div>
            </div>
          </div>
          <div class="col-lg-4 col-md-6 mt-md-0 mt-5">
            <div class="features-with-17-right-tp_sur">
              <div class="features-with-17-left1 mb-3">
                <span class="fa fa-ils" aria-hidden="true"></span>
              </div>
              <div class="features-with-17-left2">
                <h6><a href="#url">Conceptual Architecture</a></h6>
                <p>We work with the range of crafts people in the field of furnitures, 
                  electronics, wall and floor plastering, design makers and technocrats to offer our 
                  clients bespoke and made to measure products.  
                </p>
              </div>
            </div>
          </div>
          <div class="col-lg-4 col-md-6 mt-lg-0 mt-5">
            <div class="features-with-17-right-tp_sur">
              <div class="features-with-17-left1 mb-3">
                <span class="fa fa-building" aria-hidden="true"></span>
              </div>
              <div class="features-with-17-left2">
                <h6><a href="#url">Project Management</a> </h6>
                <p>The more challenging the project, the more we put to work the range of our skills
                  in the minimum possible timeframe and with excellent management of your interior resources.
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>
<!--  //build a space section -->

<!--  recent projects section -->
<section class="w3l-index6" id="about" style="display: none;">
  <div class="features-with-17_sur">
    <div class="container py-lg-5">
      <div class="products-4" id="gallery">
        <!-- Products4 block -->
        <div id="products4-block" class="text-center">
            <div class="container">
                <div class="heading text-center mx-auto mb-5">
                    <h3 class="head">Our Recent Projects</h3>
                    <hr>
                </div>
                
                <div class="d-grid grid-col-3">
                    <div class="product">
                        <a href="/assets/images/g1.jpg" data-lightbox="example-set"
                            data-title="Lorem ipsum dolor sit amet consectetur adipisicing elit. Numquam architecto, ex veritatis">
                            <figure>
                                <img src="/assets/images/g1.jpg" class="img-responsive" alt="" />
                            </figure>
                        </a>
                        
                    </div>
                    <div class="product">
                        <a href="/assets/images/g2.jpg" data-lightbox="example-set"
                            data-title="Lorem ipsum dolor sit amet consectetur adipisicing elit. Numquam architecto, ex veritatis">
                            <figure>
                                <img src="/assets/images/g2.jpg" class="img-responsive" alt="" />
                            </figure>
                        </a>
                        
                    </div>
                    <div class="product">
                        <a href="/assets/images/g3.jpg" data-lightbox="example-set"
                            data-title="Lorem ipsum dolor sit amet consectetur adipisicing elit. Numquam architecto, ex veritatis">
                            <figure>
                                <img src="/assets/images/g3.jpg" class="img-responsive" alt="" />
                            </figure>
                        </a>
                        
                    </div>
                    <div class="product">
                        <a href="/assets/images/g4.jpg" data-lightbox="example-set"
                            data-title="Lorem ipsum dolor sit amet consectetur adipisicing elit. Numquam architecto, ex veritatis">
                            <figure>
                                <img src="/assets/images/g4.jpg" class="img-responsive" alt="" />
                            </figure>
                        </a>
                        
                    </div>
                    <div class="product">
                        <a href="/assets/images/g5.jpg" data-lightbox="example-set"
                            data-title="Lorem ipsum dolor sit amet consectetur adipisicing elit. Numquam architecto, ex veritatis">
                            <figure>
                                <img src="/assets/images/g5.jpg" class="img-responsive" alt="" />
                            </figure>
                        </a>
                       
                    </div>
                    <div class="product">
                        <a href="/assets/images/g6.jpg" data-lightbox="example-set"
                            data-title="Lorem ipsum dolor sit amet consectetur adipisicing elit. Numquam architecto, ex veritatis">
                            <figure>
                                <img src="/assets/images/g6.jpg" class="img-responsive" alt="" />
                            </figure>
                        </a>
                        
                    </div>
                    
                    
                </div>
            </div>
        </div>
        <!-- Products4 block -->
    </div>
    </div>
  </div>
</section>
<!--  //recent projects section -->

<script src="/assets/js/gallery.js"></script>
<script src="/assets/js/jquery-3.3.1.min.js"></script>
<script src="/assets/js/lightbox-plus-jquery.min.js"></script>

<!-- footer -->
<?php include 'footer.inc.php'; ?>
<!-- // footer -->

<script src="/assets/js/jquery-3.3.1.min.js"></script>

<script>
    $(function () {
      $('.navbar-toggler').click(function () {
        $('body').toggleClass('noscroll');
      })
    });
</script>
  <!-- jQuery first, then Popper.js, then Bootstrap JS -->
  <script src="https://code.jquery.com/jquery-3.4.1.slim.min.js"
    integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous">
  </script>
  
  <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"
    integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous">
  </script>

<!-- Smooth scrolling -->

<script src="/assets/js/owl.carousel.js"></script>

<!-- script for -->
<script>
  $(document).ready(function () {
    $('.owl-one').owlCarousel({
      loop: true,
      margin: 0,
      nav: true,
      responsiveClass: true,
      autoplay: false,
      autoplayTimeout: 5000,
      autoplaySpeed: 1000,
      autoplayHoverPause: false,
      responsive: {
        0: {
          items: 1,
          nav: false
        },
        480: {
          items: 1,
          nav: false
        },
        667: {
          items: 1,
          nav: true
        },
        1000: {
          items: 1,
          nav: true
        }
      }
    })
  })
</script>
<!-- //script -->

</body>

</html>
<!-- // grids block 5 -->
